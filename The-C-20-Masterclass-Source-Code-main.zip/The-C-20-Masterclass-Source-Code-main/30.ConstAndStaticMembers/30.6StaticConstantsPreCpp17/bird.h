#ifndef BIRD_H
#define BIRD_H

class Bird
{
  public:
    static const float BIRD_WEIGHT_CONSTANT;
};

#endif // BIRD_H