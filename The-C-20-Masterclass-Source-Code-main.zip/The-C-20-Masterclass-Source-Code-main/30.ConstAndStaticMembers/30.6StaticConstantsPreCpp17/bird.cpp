#include "bird.h"
#include "cylinder.h"

const float Bird::BIRD_WEIGHT_CONSTANT {Cylinder::FLOAT_CONSTANT};