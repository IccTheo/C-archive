#include <iostream>
#include "outer.h"


int main(){

    Outer outer1(10,20.1);
    outer1.do_something();

    
   
    return 0;
}