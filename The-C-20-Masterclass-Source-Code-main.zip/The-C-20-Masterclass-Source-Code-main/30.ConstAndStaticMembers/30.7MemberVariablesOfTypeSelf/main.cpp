#include <iostream>
#include "point.h"

int main(){

    Point p1(5,5); // The most vexing parse
    p1.initialize_pointer(10,10);

    p1.m_point4.print_info();



 
    return 0;
}