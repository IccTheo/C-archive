#include "car.h"

Car::Car(const std::string& color, int speed) : 
    m_color(color),m_speed(speed)
{
}

Car::~Car()
{
}


