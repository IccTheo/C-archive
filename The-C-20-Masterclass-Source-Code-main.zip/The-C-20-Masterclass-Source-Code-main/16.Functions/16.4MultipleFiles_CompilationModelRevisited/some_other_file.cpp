//Definition
int max( int a, int b){
    if(a>b)
        return a;
    else
        return b;
}

